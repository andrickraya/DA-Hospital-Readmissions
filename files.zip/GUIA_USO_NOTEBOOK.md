# 📚 GUÍA DE USO - Data Analytics 101 Notebook
## Análisis de Readmisiones Hospitalarias

---

## 🚀 CÓMO COMENZAR

### Paso 1: En Google Colab
1. Ve a [Google Colab](https://colab.research.google.com/)
2. Carga tu notebook: `Data_Analytics_Readmissions.ipynb`
3. Selecciona **Runtime → Change runtime type → Python 3**

### Paso 2: Descargar el Dataset
Ejecuta la celda de **"Descarga de Dataset"** que incluye:
- Autenticación con Kaggle (necesitas archivo `kaggle.json`)
- Descarga automática de "Diabetes 130-Hospitals"

> **Si ya tienes el dataset:** Cárgalo directamente y salta al Paso 3

### Paso 3: Ejecutar Secuencialmente
El notebook está diseñado para ejecutarse de arriba hacia abajo:
- ✅ Sección 0: Setup e imports
- ✅ Sección 1: Carga y exploración
- ✅ Sección 2: Calidad de datos (20 pts)
- ✅ Sección 3: EDA (25 pts)
- ✅ Sección 4: Inferencia estadística (25 pts)
- ✅ Sección 5: Modelado (20 pts)
- ✅ Sección 6: Resumen (10 pts)

---

## 📊 ESTRUCTURA DEL NOTEBOOK

### SECCIÓN 0: Setup (5 mins)
**Qué hace:**
- Importa librerías: pandas, scipy, sklearn, matplotlib, seaborn
- Configura estilos de gráficos

**Esperado:**
```
✅ Librerías importadas correctamente
```

---

### SECCIÓN 1: Carga de Datos (10 mins)
**Qué hace:**
- Descarga dataset desde Kaggle
- Carga archivo CSV
- Muestra primeras/últimas filas
- Inspecciona tipos de datos

**Esperado:**
- Dataset: ~100,000 registros × 50 variables
- Confirmación de carga exitosa

---

### SECCIÓN 2: Calidad del Dato (15 pts/20)
**Subsecciones:**

#### 2.1 Valores Faltantes
- Visualiza % de NAs por columna
- Genera gráfico de distribución
- Decide estrategia: eliminar vs. imputar

**Esperado:**
```
Variable: Missing_Count  Missing_Percentage
diag_3:        1426      1.426%
...
```

#### 2.2 Outliers
- Método IQR (Interquartile Range)
- Genera boxplots
- Justifica mantener/eliminar

**Esperado:**
```
num_medications: 58 outliers (0.058%)
```

#### 2.3 Limpieza & Transformación
- Convierte `readmitted` a binaria (0/1)
- Extrae edad numérica de rangos
- Codifica variables categóricas

**Esperado:**
```
readmitted_binary: 0 = 88.84%, 1 = 11.16%
age_numeric: rango 20-100, media 58.1
```

#### 2.4 Resumen de Decisiones
- Documenta todas las transformaciones

---

### SECCIÓN 3: EDA - Análisis Exploratorio (25 pts)
**Subsecciones:**

#### 3.1 Análisis Univariado
- Distribución de readmisiones (target)
- Distribución de duración de estancias
- Distribución de admisiones previas
- Tests de normalidad (Shapiro-Wilk)

**Esperado:**
```
Readmisiones: 11.16% (desbalanceado)
Días estancia: Media=4.3, Mediana=3 (asimétrica)
Admisiones previas: Conteo (0-20+), posible sobredispersión
```

#### 3.2 Análisis Bivariado
- Readmisión vs. género (Chi-cuadrado)
- Readmisión vs. medicamentos (T-test)
- Duración vs. admisiones previas (correlación)

**Esperado:**
```
Género-Readmisión: χ² = X.XX, p = 0.XXXX
Medicamentos-Readmisión: t = X.XX, p = 0.XXXX
```

---

### SECCIÓN 4: Inferencia Estadística (25 pts)
**Subsecciones:**

#### 4.1 Pruebas de Normalidad
- Shapiro-Wilk test
- Kolmogorov-Smirnov test
- Conclusión: ¿Datos normales?

**Esperado:**
```
time_in_hospital: p < 0.05 → NO normal
→ Usar tests no-paramétricos
```

#### 4.2 Pruebas de Hipótesis

**H1: Duración ≠ por readmisión**
- Welch's t-test o Mann-Whitney U
- Resultado: ¿Significancia?

**H2: Medicamentos ≠ por edad**
- ANOVA o Kruskal-Wallis
- Resultado: ¿Diferencia entre grupos?

**H3: Readmisión ⊥ cambio medicación**
- Chi-cuadrado
- Resultado: ¿Independencia?

**Esperado:**
```
H1: p = 0.0001 ✗ DIFERENCIA SIGNIFICATIVA
H2: p = 0.3402 ✓ SIN DIFERENCIA
H3: p = 0.0012 ✗ ASOCIACIÓN SIGNIFICATIVA
```

---

### SECCIÓN 5: Modelado Estadístico (20 pts)
**3 Modelos Implementados:**

#### 5.1 Regresión Logística (Readmisión)
- Variable target: readmitted_binary (1/0)
- Variables predictoras: edad, medicamentos, procedimientos, admisiones, emergencias
- Output: Coeficientes, Odds Ratios, ROC-AUC

**Esperado:**
```
age_numeric: Coef=-0.0234, OR=0.977
→ Aumentar edad 1 año → DISMINUYE readmisión 2.3%

ROC-AUC: 0.65-0.75 (modelo débil-moderado)
```

#### 5.2 Regresión de Poisson (Admisiones Previas)
- Variable target: number_inpatient (conteo)
- Diagnóstico: ¿Sobredispersión?
- Output: Coeficientes, MAE/RMSE

**Esperado:**
```
number_medications: Coef=0.023, exp(Coef)=1.023
→ Medicamento adicional → +2.3% admisiones esperadas

Overdispersion index: 1.45 (> 1.1) → CONSIDERAR Binomial Negativa
```

#### 5.3 Regresión Lineal (Duración Estancia)
- Variable target: time_in_hospital (días)
- Diagnóstico de supuestos: normalidad, homocedasticidad
- Output: Coeficientes, R², RMSE

**Esperado:**
```
readmitted_binary: Coef=0.342
→ Readmitidos esperan 0.34 días ADICIONALES

R² = 0.15 (explica 15% varianza)
RMSE = 2.3 días
```

---

### SECCIÓN 6: Resumen Ejecutivo (10 pts)
- Resumen de 3 hallazgos principales
- Recomendaciones para directivos del hospital
- Próximos pasos

**Esperado:**
```
✓ Resumen claro de interpretaciones clínicas
✓ Conexión entre análisis y decisiones de negocio
```

---

## 📈 VISUALIZACIONES CLAVE

El notebook genera ~20+ gráficos:

### Gráficos de Calidad de Datos
- Bar plot: Valores faltantes por variable
- Boxplots: Outliers por variable

### Gráficos EDA
- Histogramas: Distribuciones univariadas
- Q-Q plots: Normalidad
- Bar plots: Categorías
- Scatter plots: Correlaciones

### Gráficos de Inferencia
- Tablas: Resultados de tests

### Gráficos de Modelado
- **Logística:** Curva ROC, coeficientes
- **Poisson:** Residuos vs predicciones
- **Lineal:** Predichos vs reales, residuos, Q-Q plot

---

## 🎯 MÉTRICAS CLAVE A SEGUIR

### Fase 1 (Datos): 20 pts
✓ Identificar missing values con justificación
✓ Detectar outliers (método IQR)
✓ Transformaciones bien documentadas

### Fase 2 (EDA): 25 pts
✓ Mínimo 5-6 visualizaciones distintas
✓ Interpretación clara de patrones
✓ Análisis uni/bivariado/multivariado

### Fase 3 (Inferencia): 25 pts
✓ Mínimo 5 pruebas estadísticas
✓ Verificación de supuestos
✓ Interpretación en contexto clínico

### Fase 4 (Modelado): 20 pts
✓ 3 modelos correctamente implementados
✓ Diagnóstico de supuestos
✓ Interpretación de coeficientes

### Fase 5 (Comunicación): 10 pts
✓ Código reproducible y comentado
✓ Informe con insights accionables
✓ Presentación visual

---

## 💡 CONSEJOS DE OPTIMIZACIÓN

### Para Colab
```python
# Aumentar tiempo de sesión
from google.colab import auth
auth.authenticate_user()

# Visualizar más datos
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
```

### Para Velocidad
- La primera ejecución es lenta (imports)
- Después corre rápido (~2-3 minutos total)
- Cachea resultados si necesitas reejecutar

### Para Reproducibilidad
- Fija `random_state=42` en todos los modelos
- Usa `np.random.seed(42)` al inicio
- Documenta versiones de librerías

---

## 🔧 TROUBLESHOOTING

### Error: "ModuleNotFoundError"
```python
# Instalar en Colab
!pip install scipy scikit-learn seaborn matplotlib pandas numpy
```

### Error: "File not found" para Kaggle
```python
# Verificar credenciales
!cat ~/.kaggle/kaggle.json
# Debe contener tu API key de Kaggle
```

### Error: "Too many rows"
```python
# Limitar a muestra para tests rápidos
df_sample = df.sample(n=10000, random_state=42)
```

---

## 📋 CHECKLIST ANTES DE ENTREGAR

- [ ] Notebook ejecuta de inicio a fin sin errores
- [ ] Todas las celdas tienen markdown explicativo
- [ ] Decisiones de preprocesamiento están justificadas
- [ ] EDA incluye visualizaciones interpretadas
- [ ] Tests estadísticos tienen p-values reportados
- [ ] 3 Modelos con diagnóstico de supuestos
- [ ] Coeficientes interpretados en contexto clínico
- [ ] Resumen ejecutivo claro y accionable
- [ ] Código está comentado y reproducible
- [ ] Variables de interés están claramente identificadas

---

## 📞 PRÓXIMOS PASOS

1. **Ejecutar este notebook completamente**
   - Toma ~5-10 minutos en Colab
   - Guarda output con todos los gráficos

2. **Crear Informe PDF** (5-7 páginas)
   - Resumen ejecutivo (1 pg)
   - Metodología (1 pg)
   - Hallazgos (2-3 pgs)
   - Recomendaciones (1 pg)

3. **Crear Presentación** (5-6 diapositivas)
   - Slide 1: Contexto & Objetivos
   - Slide 2-3: Hallazgos principales (con gráficos)
   - Slide 4: Recomendaciones
   - Slide 5: Conclusiones

---

**¡Buena suerte con tu análisis!** 🎉
