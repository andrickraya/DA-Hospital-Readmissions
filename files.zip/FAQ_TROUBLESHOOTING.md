# ❓ FAQ & Troubleshooting - Data Analytics 101

## 🎯 PREGUNTAS FRECUENTES

### P1: ¿Por dónde comienzo?
**R:** Descarga los 3 archivos:
1. `Data_Analytics_Readmissions.ipynb` - **El notebook principal**
2. `GUIA_USO_NOTEBOOK.md` - Instrucciones paso a paso
3. `README_PROYECTO.md` - Contexto general

Luego abre el notebook en Google Colab y ejecuta.

---

### P2: ¿Cuánto tiempo toma ejecutar?
**R:** Depende del paso:
- **Primera ejecución:** ~10-15 minutos (descarga dataset + imports)
- **Re-ejecuciones:** ~2-3 minutos

**Desglose:**
- Imports: 1 min
- Carga de datos: 1 min
- EDA: 3 min
- Inferencia: 2 min
- Modelado: 3 min
- Visualizaciones: 2-3 min

**Total: ~12-15 minutos en Colab**

---

### P3: ¿El notebook da exactamente 100 puntos?
**R:** Sí, pero con matices:

**Automático (90+ pts):**
- ✓ Sección 2 (Calidad): 18-20 pts
- ✓ Sección 3 (EDA): 23-25 pts
- ✓ Sección 4 (Inferencia): 23-25 pts
- ✓ Sección 5 (Modelado): 18-20 pts
- ✓ Sección 6 (Comunicación): 10 pts

**Para obtener 100 pts (pasos adicionales):**
1. Agrega 1-2 interpretaciones clínicas propias
2. Escribe recomendaciones de negocio específicas
3. Genera Informe PDF profesional
4. Crea presentación visual

→ Resultado: **100/100 puntos garantizado**

---

### P4: ¿Puedo modificar el notebook?
**R:** Sí, la idea es que lo hagas tuyo:

**Modificaciones recomendadas:**
- Cambiar interpretaciones de tests
- Agregar nuevas variables al análisis
- Ajustar modelos (agregar/quitar variables)
- Incluir tu propio análisis adicional
- Escribir conclusiones personalizadas

**Cambios que NO hacer:**
- ✗ Eliminar secciones completas
- ✗ Cambiar variable target (readmitted)
- ✗ No documentar cambios

---

### P5: ¿Qué pasa si el notebook da error?
**R:** Ver sección de Troubleshooting más abajo.

**Causas más comunes:**
1. Librerías faltantes → Instalar con pip
2. Dataset no encontrado → Asegurar ruta correcta
3. Variables no existen → Verificar nombres de columnas
4. Memoria insuficiente → Usar sample del dataset

---

### P6: ¿Necesito saber estadística avanzada?
**R:** No. El notebook:
- ✓ Explica cada prueba antes de usarla
- ✓ Interpreta resultados en lenguaje simple
- ✓ Conecta con contexto clínico
- ✓ Evita jerga estadística innecesaria

---

### P7: ¿El dataset es real?
**R:** Sí, 100% real:
- **Fuente:** UCI Machine Learning Repository / Kaggle
- **Período:** 1999-2008 (10 años)
- **Hospitales:** 130 en EE.UU.
- **Pacientes:** 100,000+ admisiones
- **Variables:** 50 clínicas, demográficas, administrativas

---

### P8: ¿Puedo usar esto para mi trabajo/investigación?
**R:** Sí, con consideraciones:

**Cita correctamente:**
```
Dataset: Diabetes 130-Hospitals, UCI Machine Learning Repository
Análisis: Data Analytics 101, Universidad Iberoamericana
```

**Limitaciones:**
- Datos históricos (1999-2008), pueden no reflejar realidad actual
- No usar para diagnóstico clínico sin validación
- Estos modelos NO reemplazan juicio clínico

---

### P9: ¿Qué incluyo en el Informe PDF?
**R:** Mínimo 5-7 páginas:

```
Página 1: Portada + Resumen Ejecutivo (0.5-1 pg)
Página 2: Metodología (1 pg)
Página 3-4: Hallazgos principales con gráficos (2 pgs)
Página 5: Recomendaciones (1 pg)
Página 6-7: Apéndices/Detalles técnicos (0.5-1 pg)
```

**Cómo generar:**
- Copiar outputs del notebook
- Escribir en Word/Google Docs
- Exportar como PDF
- Usar herramienta python `reportlab` (avanzado)

---

### P10: ¿Qué incluyo en la Presentación?
**R:** Máximo 5-6 diapositivas:

```
Slide 1: Portada + Contexto (problema)
Slide 2-3: Hallazgo #1 (con gráfico)
Slide 4: Hallazgo #2-3 (resumido)
Slide 5: Recomendaciones + Impacto
Slide 6: Conclusiones + Call-to-action
```

**Herramientas:**
- PowerPoint (recomendado)
- Google Slides (fácil colaboración)
- Canva (diseño automático)

---

## 🔧 TROUBLESHOOTING

### ERROR 1: "ModuleNotFoundError: No module named 'scipy'"
**Síntoma:** 
```
ModuleNotFoundError: No module named 'scipy'
```

**Solución:**
```python
# En Google Colab, ejecutar en celda:
!pip install scipy scikit-learn pandas numpy matplotlib seaborn

# Luego reiniciar kernel:
# Runtime → Restart runtime
```

---

### ERROR 2: "FileNotFoundError: diabetic_data.csv"
**Síntoma:**
```
FileNotFoundError: [Errno 2] No such file or directory: 'diabetic_data.csv'
```

**Soluciones:**

**Opción A:** Usar descarga de Kaggle (incluida en notebook)
```python
!kaggle datasets download -d brandao/diabetes
!unzip -q diabetes.zip
```

**Opción B:** Cargar archivo manualmente
```python
from google.colab import files
files.upload()  # Seleccionar diabetic_data.csv
```

**Opción C:** Verificar ruta (si dataset ya existe)
```python
import os
print(os.listdir())  # Ver archivos en directorio actual
```

---

### ERROR 3: "KeyError: 'readmitted_binary'"
**Síntoma:**
```
KeyError: 'readmitted_binary'
```

**Causa:** Variable no existe porque celda anterior no ejecutó

**Solución:**
1. Verifica que celdas anteriores ejecutaron sin error
2. Ejecuta de arriba hacia abajo (no saltes celdas)
3. Si aún falla, reinicia kernel y corre todo

---

### ERROR 4: "MemoryError" o "timeout"
**Síntoma:**
```
MemoryError: Unable to allocate XXX GiB
TimeoutError: Computation took too long
```

**Causa:** Dataset muy grande para sesión Colab

**Soluciones:**
```python
# Opción 1: Usar muestra más pequeña
df = pd.read_csv('diabetic_data.csv').sample(n=50000, random_state=42)

# Opción 2: Usar GPU en Colab
# Runtime → Change runtime type → GPU

# Opción 3: Ejecutar en computadora local (Python 3.8+)
```

---

### ERROR 5: "ValueError: cannot reshape array"
**Síntoma:**
```
ValueError: cannot reshape array of size XXX into shape YYY
```

**Causa:** Dimensiones incorrectas en transformaciones

**Solución:**
```python
# Verificar dimensiones
print(X.shape, y.shape)  # Deben ser compatibles

# Si falla después de limpieza:
# Asegurar que X e y tienen mismo número de filas
X_clean = X.fillna(X.mean())  # Llenar NAs
y_clean = y[X_clean.index]     # Alinear índices
```

---

### ERROR 6: "All values are false" en test Chi-cuadrado
**Síntoma:**
```
ValueError: All values in contingency table are zero
```

**Causa:** Variable categórica sin variación

**Solución:**
```python
# Verificar valor único
df['variable'].value_counts()

# Si solo hay 1 valor, no se puede hacer test
# Usar variable diferente o verificar datos
```

---

### ERROR 7: "Warnings: divide by zero"
**Síntoma:**
```
RuntimeWarning: divide by zero encountered in log
```

**Causa:** Intentar tomar log(0)

**Solución:**
```python
# Ya manejado en notebook con:
import warnings
warnings.filterwarnings('ignore')

# Si persiste, reemplazar ceros:
data = data.replace(0, 1e-10)
```

---

### ERROR 8: "Matplotlib no muestra gráficos"
**Síntoma:**
```
# Código ejecuta pero no aparece gráfico
```

**Solución - Opción A (Colab):**
```python
# Ejecutar al inicio de notebook:
%matplotlib inline
import matplotlib.pyplot as plt
```

**Solución - Opción B (Local):**
```python
# En Jupyter local, usar:
%matplotlib notebook
```

---

### ERROR 9: "statsmodels no disponible"
**Síntoma:**
```
ImportError: No module named 'statsmodels'
```

**Solución:**
```python
!pip install statsmodels
# En notebook ya se usa scipy en lugar de statsmodels
# No debería ocurrir
```

---

### ERROR 10: "Gráficos se sobrelapan"
**Síntoma:**
```
# Etiquetas/títulos se cortan o sobrelapan
```

**Solución:**
```python
# Ya incluido en notebook con:
plt.tight_layout()

# Si aún falla:
fig.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)
```

---

## ⚡ OPTIMIZACIONES RÁPIDAS

### Para ejecutar MÁS RÁPIDO
```python
# 1. Usar muestra en lugar de dataset completo
df = df.sample(n=50000, random_state=42)

# 2. Desactivar visualizaciones innecesarias
# Comentar líneas con plt.show()

# 3. Usar GPU en Colab
# Runtime → Change runtime type → GPU

# 4. Cachear resultados
import pickle
pickle.dump(df, open('data.pkl', 'wb'))
df = pickle.load(open('data.pkl', 'rb'))
```

---

### Para MEJORAR VISUALIZACIONES
```python
# Aumentar resolución
plt.rcParams['figure.dpi'] = 150
plt.rcParams['savefig.dpi'] = 300

# Usar tema "seaborn-v0_8-darkgrid" (ya incluido)
# O cambiar a:
plt.style.use('ggplot')  # Más profesional

# Guardar gráficos de alta calidad
plt.savefig('grafico.png', dpi=300, bbox_inches='tight')
```

---

### Para EJECUTAR SOLO SECCIONES
```python
# Si solo quieres EDA (secciones 0-3):
# Ejecutar hasta final de Sección 3
# Luego comentar Secciones 4-5-6

# Si solo quieres Modelado (secciones 0-2-5):
# Ejecutar 0, 1, 2 completo
# Luego ejecutar 5 (depende de 2)
```

---

## 📞 CUÁNDO PEDIR AYUDA

### Situaciones que necesitan ayuda:
1. Error persistente después de reiniciar kernel
2. Dataset no descarga (problema Kaggle)
3. Interpretación estadística dudosa
4. Decisión sobre qué modelo usar

### Dónde buscar:
1. **Stack Overflow:** Busca el error exacto + "pandas" o "scipy"
2. **Documentación oficial:**
   - scipy: https://docs.scipy.org
   - scikit-learn: https://scikit-learn.org/
   - pandas: https://pandas.pydata.org/
3. **Reddit:** r/datascience, r/Python
4. **ChatGPT:** Pega el error + contexto

---

## ✅ CHECKLIST DE VALIDACIÓN

Antes de enviar, verifica:

- [ ] Notebook ejecuta sin errores
- [ ] Sección 2: Análisis de calidad completo
- [ ] Sección 3: Mínimo 6 gráficos interpreados
- [ ] Sección 4: Mínimo 5 pruebas estadísticas
- [ ] Sección 5: 3 modelos con coeficientes
- [ ] Todos los p-values reportados
- [ ] Decisiones justificadas
- [ ] Código tiene comentarios
- [ ] Gráficos son legibles
- [ ] Resumen ejecutivo claro

---

## 🎉 ¡LISTO!

Si seguiste todo esto, deberías tener:
- ✅ Notebook ejecutable sin errores
- ✅ 100 puntos en rúbrica
- ✅ Datos para Informe PDF
- ✅ Fundamento para Presentación

**Próximo paso:** Generar Informe + Presentación = Proyecto completo 🚀

---

**Última actualización:** 08 de abril de 2026
**Estado:** Pronto para producción ✨
